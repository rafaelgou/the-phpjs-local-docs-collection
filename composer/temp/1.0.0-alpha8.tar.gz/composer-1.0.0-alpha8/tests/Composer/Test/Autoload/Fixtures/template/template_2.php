/*
 * class templateClass_2
 * interface templateInterface_2
 * trait temlpateTrait_2
 */
<?php
    echo $code
?>
